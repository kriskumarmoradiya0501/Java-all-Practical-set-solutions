class invalidValue extends Exception{
    public invalidValue(String msg){
        super(msg);
    }
}
class Floor{
    double width;
    double length;
    public Floor(double width,double length) throws invalidValue{
        if(width<0 || length<0){
            throw new invalidValue("invalide");
        }
        this.width=width;
        this.length=length;
    }
    public double getArea(){
        return width*length;
    }
}

class Carpet{
    double cost;
    public Carpet(double cost){
        this.cost=cost;
    }
    public double getCost(){
        return cost;
    }
}

class Calculator{
    public Floor f;
    public Carpet c;

    public Calculator(Floor f,Carpet c){
        this.c=c;
        this.f=f;
    }
    public double getTotalcost(){
        return f.getArea()*c.getCost();
    }
}

public class Div_4_Set_1 {
    public static void main(String[] atgs){
        try{
            Floor f = new Floor(15.0,10.0);
            Carpet c =new Carpet(650);
            Calculator clt = new Calculator(f,c);

            double totalCost = clt.getTotalcost();
            System.out.println(totalCost);
        }
        catch (invalidValue e){
            System.out.println(e.getMessage());
        }
    }
}
