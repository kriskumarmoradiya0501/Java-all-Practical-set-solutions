import java.util.ArrayList;
import java.util.List;

class invalidValue4 extends Exception{
    public invalidValue4(String msg){
        super(msg);
    }
}

class BankAccount{
    public String accountHolderName;
    public double balance;
    BankAccount(String accountHolderName,double balance){
        this.accountHolderName=accountHolderName;
        this.balance=balance;
    }
    void deposit(double balance){
        this.balance+=balance;
    }
    void withdraw(double balance)throws invalidValue4{
        if(this.balance<balance){
            throw new invalidValue4("invalid");
        }
        else {
            this.balance -= balance;
        }
    }
    double calculateInterest(double interest){
        interest = (interest*100)/this.balance;
        this.balance+=interest;
        return balance;
    }
    public String toString() {
        return "accountHolderName: " + accountHolderName + ", balance: " + balance;
    }
}

class InterestCalculator{
    double interestRate;
    InterestCalculator(double interestRate){
        this.interestRate=interestRate;
    }

    void applyInterest(BankAccount account){
        double interest = (interestRate*account.balance)/100;
        account.balance+=interest;
        System.out.println("Interest applied...");
    }
}

class TransactionHistory{

    public List<String> transactionList;
    TransactionHistory(){
        this.transactionList=new ArrayList<>();
    }
    void addTransaction(BankAccount ba){
        transactionList.add(ba.toString());
    }

    void printHistory(){
        if(transactionList.isEmpty()){
            System.out.println("not available");
        }
        else {
            System.out.println("History : ");
            for(String transaction : transactionList){
                System.out.println(transaction);
            }
        }
    }
}

public class Div_1_Set_3 {
    public static void main(String[] args) {
        BankAccount account = new BankAccount("Smit", 100000);
        TransactionHistory history = new TransactionHistory();

        history.addTransaction(account);

        InterestCalculator ic = new InterestCalculator(5.0);

        ic.applyInterest(account);

        history.addTransaction(account);

        account.deposit(500.0);
        history.addTransaction(account);
        try {
            account.withdraw(200.0);
            history.addTransaction(account);
        } catch (invalidValue4 e) {
            System.out.println(e.getMessage());
        }

        history.printHistory();
    }
}
