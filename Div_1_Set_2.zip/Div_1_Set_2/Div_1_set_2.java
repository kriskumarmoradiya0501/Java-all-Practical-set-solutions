import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class BookNotFoundException extends Exception {
    public BookNotFoundException(String message) {
        super(message);
    }
}

class Book{
    public String title;
    public String author;
    public double price;
    public boolean isAvailable;
    Book(String author,String title,double price,boolean isAvailable){
        this.author=author;
        this.price=price;
        this.isAvailable=isAvailable;
        this.title=title;
    }
    public void checkOut(){
        this.isAvailable=false;
    }
    public void returnBook(){
        this.isAvailable=true;
    }
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", Price: $" + price + ", Available: " + isAvailable;
    }
}

class Library{
    private List<Book> booklist;

    public Library() {
        this.booklist = new ArrayList<>();
    }

    public void addBook(Book book){
        booklist.add(book);
    }

    public List<Book> getAvailableBooks() {
        List<Book> available = new ArrayList<>();
        for (Book book : booklist) {
            if (book.isAvailable) {
                available.add(book);
            }
        }
        return available;
    }
    public Book findBookByTitle(String title) throws BookNotFoundException {
        for (Book book : booklist) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        throw new BookNotFoundException("not found.");
    }
}

class LibrarySystem {
    public Library library;

    public LibrarySystem() {
        this.library = new Library();
    }

    public void addBook(String author, String title, double price, boolean isAvailable) {
        Book newBook = new Book(author, title, price, isAvailable);
        library.addBook(newBook);
        System.out.println("Book added successfully.");
    }

    public void listAvailableBooks() {
        List<Book> available = library.getAvailableBooks();
        if (available.isEmpty()) {
            System.out.println("not available.");
        } else {
            System.out.println("available.");
            for (Book book : available) {
                System.out.println(book);
            }
        }
    }

    public void checkOutBook(String title) {
        try {
            Book book = library.findBookByTitle(title);
            if (book.isAvailable) {
                book.checkOut();
                System.out.println("checked out" + title);
            } else {
                System.out.println("not available: " + title);
            }
        } catch (BookNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public void returnBook(String title) {
        try {
            Book book = library.findBookByTitle(title);
            if (!book.isAvailable) {
                book.returnBook();
                System.out.println("returned" + title);
            } else {
                System.out.println("already available: " + title);
            }
        } catch (BookNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}

public class Div_1_set_2 {
    public static void main(String[] args) {
        LibrarySystem ls = new LibrarySystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1 for add book");
            System.out.println("2 list available book");
            System.out.println("3 chekedout");
            System.out.println("4 return");
            System.out.println("5 exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("enter author:");
                    String author = scanner.nextLine();
                    System.out.print("Enter title ");
                    String title = scanner.nextLine();
                    System.out.print("Enter price:");
                    double price = scanner.nextDouble();
                    System.out.print("available(true/false)");
                    boolean isAvailable = scanner.nextBoolean();
                    ls.addBook(author, title, price, isAvailable);
                    break;

                case 2:
                    ls.listAvailableBooks();
                    break;

                case 3:
                    System.out.print("enter title for checkout");
                    title = scanner.nextLine();
                    ls.checkOutBook(title);
                    break;

                case 4:
                    System.out.print("Enter book title to return");
                    String returnTitle = scanner.nextLine();
                    ls.returnBook(returnTitle);
                    break;

                case 5:
                    System.out.println("exit....");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid");
            }
        }
    }
}
