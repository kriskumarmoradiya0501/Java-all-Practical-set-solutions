class InvalidValue2 extends Exception {
    public InvalidValue2(String msg) {
        super(msg);
    }
}

class Circle {
    double radius;

    public Circle(double radius) throws InvalidValue2 {
        if (radius < 0) {
            throw new InvalidValue2("Invalid");
        }
        this.radius = radius;
    }

    public double getArea() {
        double pi = Math.PI;
        return pi * radius * radius;
    }
}

class Cylinder extends Circle {
    double height;

    public Cylinder(double radius, double height) throws InvalidValue2 {
        super(radius);
        if (height < 0) {
            throw new InvalidValue2("Invalid");
        }
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public double getVolume() {
        return getArea() * getHeight();
    }
}

public class Div_4_Set_2 {
    public static void main(String[] args) {
        try {
            Cylinder c = new Cylinder(10, 5);
            double volume = c.getVolume();
            System.out.println("Volume: " + volume);
            double height = c.getHeight();
            System.out.println("Height: " + height);
        } catch (InvalidValue2 e) {
            System.out.println(e.getMessage());
        }
    }
}
