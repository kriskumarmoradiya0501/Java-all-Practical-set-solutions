import java.util.ArrayList;
import java.util.List;

class InvalidValue3 extends Exception {
    public InvalidValue3(String msg) {
        super(msg);
    }
}

class Employee {
    private String name;
    private double hourlyWage;
    private int hoursWorked;

    // Constructor
    public Employee(String name, double hourlyWage, int hoursWorked) throws InvalidValue3 {
        if (hoursWorked < 0) {
            throw new InvalidValue3("Invalid.");
        }
        this.name = name;
        this.hourlyWage = hourlyWage;
        this.hoursWorked = hoursWorked;
    }

    public double getMonthlySalary() {
        return hourlyWage * hoursWorked;
    }

    public void addHours(int addhours) throws InvalidValue3 {
        if (addhours < 0) {
            throw new InvalidValue3("Additional hours cannot be negative.");
        }
        this.hoursWorked += addhours;
    }
}

class SalaryCalculator {
    private List<Employee> employeeList;

    public SalaryCalculator() {
        this.employeeList = new ArrayList<>();
    }

    public void addEmployee(Employee employee) {
        employeeList.add(employee);
    }

    public double calculateTotalSalary() {
        double totalSalary = 0;
        for (Employee employee : employeeList) {
            totalSalary += employee.getMonthlySalary();
        }
        return totalSalary;
    }
}

// Main Class
public class Div_1_Set_1 {
    public static void main(String[] args) {
        try {
            Employee emp1 = new Employee("smit", 50, 1600);
            Employee emp2 = new Employee("raj", 60, 160000);
            Employee emp3 = new Employee("karan", 20, 2000);

            emp1.addHours(10);

            SalaryCalculator salaryCalculator = new SalaryCalculator();
            salaryCalculator.addEmployee(emp1);
            salaryCalculator.addEmployee(emp2);
            salaryCalculator.addEmployee(emp3);


            double totalSalary = salaryCalculator.calculateTotalSalary();
            System.out.println("total salary" + totalSalary);

        }
        catch (InvalidValue3 e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
